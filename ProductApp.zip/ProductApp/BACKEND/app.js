
const express = require('express');
const Productdata = require('./src/model/Productdata');
const User = require('./src/model/user');
const cors = require('cors');
const bodyparser = require('body-parser');
const jwt = require('jsonwebtoken');

var app = new express();

app.use(cors());
app.use(bodyparser.json());

app.get('/home',function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
});

app.post('/register', function(req,res) {
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    let userData = req.body;
    let user = new User(userData);
    user.save((err , registeredUser) => {
        if(err){
            console.log(err);
        } else {
            let payload = {subject: user._id};
            let token = jwt.sign(payload , 'secretKey');
            res.status(200).send({token});
        }
    })
})

app.post('/login', function(req,res) {
    let userData = req.body;
    User.findOne({email: userData.email},(err, user) => {
        if(err){
            console.log(err);
        } else {
            if(!user) {                 
                res.status(401).send('Invalid Email');
            } else {
                if(user.password !== userData.password){
                    res.status(401).send('Invalid Password')
                } else {
                    let payload = {subject: user._id};
                    let token = jwt.sign(payload , 'secretKey');
                    res.status(200).send({token});
                }
            }
        }
    })
})

app.get('/products', function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    Productdata.find()
        .then(function(products){
            res.send(products);
        });
});

app.post('/delete', function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");  
    console.log(req.body);
    console.log("Id is", req.body.id);
    Productdata.findByIdAndDelete(req.body.id)
        .then(function(products)
        {console.log("success");
            res.send(products);
    });     
});

app.get('/edit/:id',function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");  
    const id = req.params.id;
    console.log(id);
    Productdata.findById( req.params.id , function (err , product){
        res.send(product);
    });
});

  

app.put('/update', function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");  
    // console.log(req.body.product);
    const product = {
        productId : req.body.product.productId,
        productName : req.body.product.productName,
        productCode : req.body.product.productCode,
        releaseDate : req.body.product.releaseDate,
        description : req.body.product.description,
        price : req.body.product.price,
        starRating : req.body.product.starRating,
        imageUrl : req.body.product.imageUrl
    }
    
    Productdata.findByIdAndUpdate(req.body.id,product)
        .then(()=>{
            console.log('Updated Successfully');
            res.send(product);
        })    
    .catch((err)=>{
        console.log("Update failed:" , err);
        res.send({error:err});
    })
})
 
app.post('/insert', function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    console.log(req.body);
    var product = {
        productId : req.body.product.productId,
        productName : req.body.product.productName,
        productCode : req.body.product.productCode,
        releaseDate : req.body.product.releaseDate,
        description : req.body.product.description,
        price : req.body.product.price,
        starRating : req.body.product.starRating,
        imageUrl : req.body.product.imageUrl
    }
    var product = new Productdata(product);
    product.save();
});

app.listen(3000, function(){
    console.log('listening to port 3000');
});
