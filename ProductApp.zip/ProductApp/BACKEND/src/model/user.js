
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/ProductDb');

const Schema = mongoose.Schema; 
const userSchema = new Schema({
    email: String,
    password: String
});

// var Productdata = mongoose.model('product', NewProductSchema); 

var User = mongoose.model('user', userSchema );
module.exports = User;

// module.exports = mongoose.model('user', userSchema , 'users');

// module.exports = Productdata;







