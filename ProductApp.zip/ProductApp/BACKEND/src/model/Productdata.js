
const mongoose = require('mongoose');    //Accessing mongoose package

mongoose.connect('mongodb://localhost:27017/ProductDb');
//.then(() => console.log("Connected"));   //Database connection
                            
const Schema = mongoose.Schema;   //schema definition
const NewProductSchema = new Schema({
    productId: Number,
    productName: String,
    productCode: String,
    releaseDate: String,
    description: String,
    price: Number,
    starRating: Number,
    imageUrl: String
});

var Productdata = mongoose.model('product', NewProductSchema);  //model creation and collection name 

module.exports = Productdata;
