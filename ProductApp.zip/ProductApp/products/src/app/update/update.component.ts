import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ProductModel } from '../product-list/product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  title:String = "Update Product" ;
  id : string;
  products: ProductModel[];  
  imageWidth: number =50;   
  imageMargin: number = 2;    
  
  constructor(private productservice: ProductService,private router: Router) { }
  productItem = new ProductModel(null,null,null, null, null, null,null,null);   //
  
  ngOnInit(): void {
    this.productservice.getProducts()
    .subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));
    })
  }
  UpdateProduct(id){
    const data = {
        productId :this.productItem.productId,
        productName :this.productItem.productName,
        productCode :this.productItem.productCode,
        releaseDate :this.productItem.releaseDate,
        description : this.productItem.description,
        price : this.productItem.price,
        starRating : this.productItem.starRating,
        imageUrl :this.productItem.imageUrl
    };
    this.productservice.UpdateProduct(this.productItem);
    // .subscribe(
      // response => {
        // this.productItem = id;
        console.log(data);
        this.router.navigate(['/product-list']); 
      }
      // error => {
      //   console.log(error);
      // });
  }         


    // this.productservice.UpdateProduct(id)  
    //   console.log("called");  
    //   alert("success");
    //   this.router.navigate(['/product-list']); 
    
    
 //   .subscribe(result => {
      
        // const data = {
    //   title: this.currentTutorial.title,
    //   description: this.currentTutorial.description,
    //   published: status
    // };
     // }, error => console.log('There was an error: ', error));
  // }