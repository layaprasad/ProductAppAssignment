import { Component, OnInit } from '@angular/core';
import { ProductModel } from './product.model';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  title:String = "Product List";   
  products: ProductModel[];  //product is the product class for a product item
  imageWidth: number =50; //image properties    
  imageMargin: number = 2;    //image properties
  showImage: boolean = false;   //image properties

  constructor(private productService : ProductService, private router: Router) { }  //creating service object for calling getProducts()
  
  toggleImage(): void{
    this.showImage = !this.showImage;
  }

  ngOnInit(): void {   //calling  getProducts() and loading the products to products array
    this.productService.getProducts()
    .subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));
    })
  }
  deleteProduct(id){
    this.productService.deleteProduct(id).subscribe(result => {
    // this.productService.getProducts();
    this.router.navigate(['/product-list']);
    }, error => console.log('There was an error: ', error));
  }
  UpdateProduct(id){
    this.productService.UpdateProduct(id)
      this.router.navigate(['/update']);    
      console.log("update");
      // alert("success");  
  }  
}