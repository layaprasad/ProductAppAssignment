import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUserDetails={
    "email" :""  ,
    "password" : ""
  };

  constructor(private userservice:UserService, private router:Router) { }

  loginUser(){
    this.userservice.loginUser(this.loginUserDetails) 
        .subscribe(
          res=>{
              const tok = res['token'];
              console.log(res);
              localStorage.setItem('token' , tok)
              this.router.navigate(['/product-list'])
            
          },
          err=>console.log(err)
        )
        console.log("Login");
        alert("success");     
        
  }
  ngOnInit(): void {
  }

}