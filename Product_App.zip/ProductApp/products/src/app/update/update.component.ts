import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ProductModel } from '../product-list/product.model';
import { Router } from '@angular/router';
import { ActivatedRoute,ParamMap } from '@angular/router';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  title:String = "Update Product" ;
  id : string;
  products: ProductModel[];  
  imageWidth: number =50;   
  imageMargin: number = 2;    
  productItem:any;
  singleproduct:any;
  mode:string;
  constructor(private productservice: ProductService,private router: Router,private activeRoute: ActivatedRoute) { }
 
  
  
  ngOnInit(): void {
    this.activeRoute.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('productId')){
        this. mode ='update';
        console.log(this. mode)
        this. id = paramMap.get('productId'); 
        // this.isLoading = true;
        this.productservice.Update(this.id).subscribe(product => {
          this.singleproduct = JSON.parse(JSON.stringify(product));
          console.log(this.id);
          console.log(this.singleproduct)
          const {productId,productName,productCode,releaseDate,description,price,starRating,imageUrl} = this.singleproduct;    
          // console.log(this.singleproduct.product);
          this.productItem=new ProductModel(productId, productName, productCode, releaseDate, description, price, starRating, imageUrl)
           console.log(this.productItem)
        })
    }
  })
}

UpdateProduct(){ 
  this.productservice.UpdateProduct(this.productItem, this.id);
  this.router.navigate(['/product-list']); 
    }    
}
    
    
       
      // const data = {console.log(data);
    //     productId :this.productItem.productId,
    //     productName :this.productItem.productName,
    //     productCode :this.productItem.productCode,
    //     releaseDate :this.productItem.releaseDate,
    //     description : this.productItem.description,
    //     price : this.productItem.price,
    //     starRating : this.productItem.starRating,
    //     imageUrl :this.productItem.imageUrl
    // };
  

    // this.productservice.UpdateProduct(id)  
    //   console.log("called");  
    //   alert("success");
    //   this.router.navigate(['/product-list']); 
    
  