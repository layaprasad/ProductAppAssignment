import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  id:string;

  constructor( private http:HttpClient) { }
  getProducts(){
    return this.http.get("http://localhost:3000/products");
  }
  deleteProduct(id){
    return this.http.post("http://localhost:3000/delete", {id:id});
  }
  Update(id){
    return this.http.get<any>(`http://localhost:3000/edit/${id}`);
  }
  UpdateProduct(productItem,id){
    return this.http.post(`http://localhost:3000/update`, {"product":productItem,id:id})
    .subscribe(((data)=>{console.log('updated product',data)}));
  }
  newProduct(item){
    return this.http.post("http://localhost:3000/insert",{"product":item})
    .subscribe(data=>{console.log(data)})
  }
}
