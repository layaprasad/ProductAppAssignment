import { Component, OnInit } from '@angular/core';
import { ProductModel } from './product.model';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  title:String = "Product List";   
  id:string;
  products: ProductModel[];  //product is the product class for a product item
  imageWidth: number =50; //image properties    
  imageMargin: number = 2;    //image properties
  showImage: boolean = false;   //image properties
  productItem:any;
  singleproduct:any;
  constructor(private productService : ProductService, private router: Router) { }  //creating service object for calling getProducts()
  
  toggleImage(): void{
    this.showImage = !this.showImage;
  }

  ngOnInit(): void {   //calling  getProducts() and loading the products to products array
   this.getProducts();
  }
  getProducts(){
    this.productService.getProducts()
    .subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));
    })
  }
  deleteProduct(id){
    this.productService.deleteProduct(id).subscribe(result => {
    // this.router.navigate(['/product-list']);
    this.productService.getProducts()
    }, error => console.log('There was an error: ', error));
  }
 
  // Update(id){
  //   this.router.navigate(['/update']);
  //   this.productService.Update(this.id).subscribe(product=>{
  //   this.singleproduct=JSON.stringify(JSON.stringify(product));
  //   console.log(this.singleproduct)
  //   const {
  //   productId ,productName ,productCode ,releaseDate ,description ,price ,starRating , imageUrl 
  //   } = this.singleproduct.product;   
     
  //   this.productItem=new ProductModel(productId, productName, productCode, releaseDate, description, price, starRating, imageUrl )

  //     })
  //   }
} 



 // UpdateProduct(id){
  //   this.productService.UpdateProduct(id).subscribe(result => {
  //     console.log(id);
  //     this.router.navigate(['/update']);    
  //     // console.log("update");
  //     // alert("success");  
  //   }, error => console.log('There was an error: ', error));
  // }